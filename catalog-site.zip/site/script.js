(() => {
'use strict';
const P = window.PAGES[document.body.dataset.page], built = window.PAGES_BUILT;
const { items, missing } = P;
const $ = s => document.querySelector(s);
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const norm = s => String(s).toLowerCase().replace(/ё/g, 'е');

const FORMATS = { orig: 'Оригинал', png: 'PNG', jpeg: 'JPEG' };
const MIME = { png: 'image/png', jpeg: 'image/jpeg' };
const EXT_MIME = { jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', gif: 'image/gif', webp: 'image/webp', avif: 'image/avif', bmp: 'image/bmp' };
const MAX_SAFE_PIXELS = 16e6; // лимит canvas на многих мобильных браузерах
const state = { vi: new Map(), fmt: 'orig', modalId: null, favOnly: false, list: [] };
const favKey = 'fav:' + document.body.dataset.page, keyOf = i => i.name + '|' + i.section; // избранное храним по названию, а не по номеру
let favs = new Set();
try { favs = new Set(JSON.parse(localStorage.getItem(favKey) || '[]')); } catch (_) { /* хранилище недоступно */ }
const byId = new Map(items.map(i => [i.id, i]));
items.forEach(i => { i._s = norm([i.name, i.location, i.group, i.authors, i.section].join(' ')); });

const el = { q: $('#q'), sec: $('#fSection'), grp: $('#fGroup'), loc: $('#fLoc'), sea: $('#fSeason'), sort: $('#fSort'),
  grid: $('#grid'), empty: $('#empty'), count: $('#count'), modal: $('#modal'), mImg: $('#mImg'), mWrap: $('#mImgWrap'),
  mTabs: $('#mTabs'), mFmt: $('#mFmt'), mDl: $('#mDl'), toast: $('#toast'), fav: $('#favOnly') };

/* ---------- фильтры ---------- */
const uniq = key => [...new Set(items.map(i => i[key]).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'ru'));
function fill(sel, label, values) {
  sel.hidden = values.length < 2; // фильтр без выбора не показываем
  sel.innerHTML = `<option value="">${label}</option>` + values.map(v => `<option>${esc(v)}</option>`).join('');
}
const SEA_ORDER = ['Общий фон', 'Зима', 'Осень', 'Весна', 'Лето', '200×300', '100×150', 'Старый формат', 'Птицы', 'Зверьки', 'Рыбы'];
function buildFilters() { // вызывается при старте и после подгрузки новых файлов; выбранные значения сохраняются
  const sels = [el.sec, el.grp, el.loc, el.sea], keep = sels.map(s => s.value);
  fill(el.sec, 'Все разделы', uniq('section'));
  fill(el.grp, 'Вся территория', uniq('group'));
  fill(el.loc, 'Все локации', uniq('location'));
  fill(el.sea, P.variantFilter || '', P.variantFilter ? [...new Set(items.flatMap(i => i.variants.map(v => v.label)))].sort((a, b) => SEA_ORDER.indexOf(a) - SEA_ORDER.indexOf(b)) : []);
  sels.forEach((s, i) => { if ([...s.options].some(o => o.value === keep[i])) s.value = keep[i]; });
}
buildFilters();
el.sort.value = P.sort;
const fmtOptions = Object.entries(FORMATS).filter(([k]) => !P.originalOnly || k === 'orig').map(([k, v]) => `<option value="${k}">${v}</option>`).join('');
el.mFmt.innerHTML = fmtOptions; el.mFmt.hidden = !!P.originalOnly;

function filtered() {
  const words = norm(el.q.value).split(/\s+/).filter(Boolean);
  const [sec, grp, loc, sea] = [el.sec.value, el.grp.value, el.loc.value, el.sea.value];
  const list = items.filter(i =>
    (!sec || i.section === sec) && (!grp || i.group === grp) && (!loc || i.location === loc) &&
    (!sea || i.variants.some(v => v.label === sea)) && (!state.favOnly || favs.has(keyOf(i))) && words.every(w => i._s.includes(w)));
  if (el.sort.value === 'table') return list.sort((a, b) => a.id - b.id);
  const dir = el.sort.value === 'za' ? -1 : 1;
  return list.sort((a, b) => dir * a.name.localeCompare(b.name, 'ru'));
}

/* ---------- карточки ---------- */
function cardHtml(it) {
  const vi = state.vi.get(it.id) || 0, v = it.variants[vi];
  const chips = it.variants.length > 1
    ? `<div class="chips">${it.variants.map((x, i) => `<button type="button" class="chip${i === vi ? ' on' : ''}" data-act="season" data-i="${i}">${esc(x.label)}</button>`).join('')}</div>` : '';
  const meta = [it.section === 'Архив старых' ? 'Архив' : (it.location || it.group), it.variants.length === 1 && v.label && v.label !== 'Общий фон' ? v.label : ''].filter(Boolean).join(' · ');
  return `<article class="card" data-id="${it.id}">
    <div class="thumb loading" data-act="open" role="button" tabindex="0" aria-label="Открыть: ${esc(it.name)}">
      <button type="button" class="star${favs.has(keyOf(it)) ? ' on' : ''}" data-act="fav" aria-label="В избранное">${favs.has(keyOf(it)) ? '★' : '☆'}</button><span class="spin"></span><img loading="lazy" decoding="async" alt="${esc(it.name)}" src="${esc(v.url)}">
      <div class="err">Файл недоступен<br><button type="button" data-act="retry">Повторить</button><a class="errlink" target="_blank" rel="noopener">открыть ссылку</a></div>
    </div>
    <div class="body"><h3>${esc(it.name)}</h3><p class="meta">${esc(meta)}</p>${chips}
      <div class="dl-row"><select class="fmt" aria-label="Формат скачивания"${P.originalOnly ? ' hidden' : ''}>${fmtOptions}</select>
      <button type="button" class="dl" data-act="dl">Скачать</button></div></div></article>`;
}

function render() {
  const list = filtered(), sea = el.sea.value;
  list.forEach(i => { if (sea) { const k = i.variants.findIndex(v => v.label === sea); if (k >= 0) state.vi.set(i.id, k); } });
  el.grid.innerHTML = list.map(cardHtml).join('');
  el.grid.querySelectorAll('.fmt').forEach(s => { s.value = state.fmt; });
  el.empty.hidden = list.length > 0;
  el.count.textContent = `Показано ${list.length} из ${items.length}`;
  el.empty.textContent = state.favOnly && !favs.size ? 'В избранном пока пусто — нажмите ☆ на карточке.' : 'Ничего не найдено. Измените запрос или фильтры.';
  state.list = list; updFav(); writeHash();
}

function reload(wrap, img, url) { // перезапуск загрузки картинки
  wrap.classList.remove('failed'); wrap.classList.add('loading');
  img.src = ''; img.src = url;
}
// load/error не всплывают — слушаем в фазе перехвата
document.addEventListener('load', e => { const w = e.target.closest && e.target.closest('.thumb,.m-img'); if (w && e.target.tagName === 'IMG') w.classList.remove('loading', 'failed'); }, true);
document.addEventListener('error', e => { const w = e.target.closest && e.target.closest('.thumb,.m-img'); if (w && e.target.tagName === 'IMG' && e.target.getAttribute('src')) { w.classList.remove('loading'); w.classList.add('failed'); const a = w.querySelector('.errlink'); if (a) a.href = e.target.src; } }, true);

el.grid.addEventListener('change', e => { if (e.target.classList.contains('fmt')) state.fmt = e.target.value; });
el.grid.addEventListener('click', e => {
  const t = e.target.closest('[data-act]'); if (!t) return;
  const card = t.closest('.card'), it = byId.get(+card.dataset.id), vi = state.vi.get(it.id) || 0;
  if (t.dataset.act === 'open') openModal(it.id);
  else if (t.dataset.act === 'fav') toggleFav(it, t);
  else if (t.dataset.act === 'dl') download(it, it.variants[vi], card.querySelector('.fmt').value, t);
  else if (t.dataset.act === 'retry') { e.stopPropagation(); reload(card.querySelector('.thumb'), card.querySelector('img'), it.variants[vi].url); }
  else if (t.dataset.act === 'season') {
    const i = +t.dataset.i; state.vi.set(it.id, i);
    card.querySelectorAll('.chip').forEach((c, k) => c.classList.toggle('on', k === i));
    reload(card.querySelector('.thumb'), card.querySelector('img'), it.variants[i].url);
  }
});
el.grid.addEventListener('keydown', e => { if ((e.key === 'Enter' || e.key === ' ') && e.target.dataset.act === 'open') { e.preventDefault(); e.target.click(); } });

/* ---------- окно просмотра ---------- */
function openModal(id, silent) {
  const it = byId.get(id), vi = state.vi.get(id) || 0; state.modalId = id;
  $('#mTitle').textContent = it.name;
  $('#mMeta').innerHTML = [it.section === 'Архив старых' ? 'Архив старых фонов' : [it.group, it.location].filter(Boolean).join(' · '), it.authors && 'Авторы: ' + it.authors].filter(Boolean).map(esc).join('<br>');
  el.mTabs.innerHTML = it.variants.length > 1 ? it.variants.map((x, i) => `<button type="button" class="chip${i === vi ? ' on' : ''}" data-i="${i}">${esc(x.label)}</button>`).join('') : '';
  el.mFmt.value = state.fmt; el.mWrap.classList.remove('zoom');
  el.mImg.alt = it.name; reload(el.mWrap, el.mImg, it.variants[vi].url);
  el.modal.hidden = false; document.body.style.overflow = 'hidden';
  const k = state.list.findIndex(x => x.id === id); $('#mPos').textContent = k >= 0 ? `${k + 1} / ${state.list.length}` : ''; syncLink();
}
function closeModal() { el.modal.hidden = true; document.body.style.overflow = ''; el.mImg.removeAttribute('src'); state.modalId = null; }
el.mTabs.addEventListener('click', e => {
  const b = e.target.closest('.chip'); if (!b) return;
  const it = byId.get(state.modalId), i = +b.dataset.i; state.vi.set(it.id, i);
  el.mTabs.querySelectorAll('.chip').forEach((c, k) => c.classList.toggle('on', k === i));
  el.mWrap.classList.remove('zoom'); reload(el.mWrap, el.mImg, it.variants[i].url); syncLink();
  const card = el.grid.querySelector(`.card[data-id="${it.id}"]`); // синхронизируем карточку
  if (card) { card.querySelectorAll('.chip').forEach((c, k) => c.classList.toggle('on', k === i)); card.querySelector('img').src = it.variants[i].url; }
});
el.mFmt.addEventListener('change', () => { state.fmt = el.mFmt.value; el.grid.querySelectorAll('.fmt').forEach(s => { s.value = state.fmt; }); });
el.mDl.addEventListener('click', () => { const it = byId.get(state.modalId); download(it, it.variants[state.vi.get(it.id) || 0], el.mFmt.value, el.mDl); });
$('#mRetry').addEventListener('click', () => { const it = byId.get(state.modalId); reload(el.mWrap, el.mImg, it.variants[state.vi.get(it.id) || 0].url); });
el.mImg.addEventListener('click', () => el.mWrap.classList.toggle('zoom'));
$('#mClose').addEventListener('click', closeModal);
el.modal.addEventListener('click', e => { if (e.target === el.modal) closeModal(); });
document.addEventListener('keydown', e => {
  const typing = /INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName);
  if (!el.modal.hidden) { if (e.key === 'Escape') closeModal(); else if (e.key === 'ArrowLeft' && !typing) step(-1); else if (e.key === 'ArrowRight' && !typing) step(1); }
  else if (e.key === '/' && !typing) { e.preventDefault(); el.q.focus(); }
});
el.q.addEventListener('keydown', e => { if (e.key === 'Escape' && el.q.value) { el.q.value = ''; render(); } });

/* ---------- скачивание и конвертация ---------- */
function toast(msg, bad) {
  el.toast.textContent = msg; el.toast.className = 'toast' + (bad ? ' bad' : ''); el.toast.hidden = false;
  clearTimeout(toast.t); toast.t = setTimeout(() => { el.toast.hidden = true; }, bad ? 7000 : 4000);
}
const safeName = s => s.replace(/[\\/:*?"<>|\u0000-\u001f]/g, '').replace(/\s+/g, ' ').trim().slice(0, 120).replace(/[. ]+$/, '');
const baseName = (it, v) => safeName(it.name + (it.variants.length > 1 ? ' — ' + v.label.toLowerCase() : '') + (it.section === 'Архив старых' ? ' (старый)' : ''));
function save(blob, filename) {
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = filename;
  document.body.append(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 5000);
}
async function toBitmap(blob) {
  if (window.createImageBitmap) { try { return await createImageBitmap(blob); } catch (_) { /* fallback ниже */ } }
  const img = new Image(); img.src = URL.createObjectURL(blob); await img.decode(); return img;
}
// Перекодирование через Canvas. JPEG: белая подложка под прозрачность, качество 1.0.
async function convert(blob, mime) {
  const bmp = await toBitmap(blob), w = bmp.width || bmp.naturalWidth, h = bmp.height || bmp.naturalHeight;
  let scale = 1;
  for (let n = 0; n < 4; n++) {
    const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w * scale)); c.height = Math.max(1, Math.round(h * scale));
    const ctx = c.getContext('2d');
    if (mime === 'image/jpeg') { ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height); }
    ctx.imageSmoothingQuality = 'high'; ctx.drawImage(bmp, 0, 0, c.width, c.height);
    const out = await new Promise(r => c.toBlob(r, mime, 1));
    if (out && out.type === mime) return { blob: out, resized: scale < 1 };
    scale = n === 0 ? Math.min(0.9, Math.sqrt(MAX_SAFE_PIXELS / (w * h))) : scale * 0.7; // браузер отказал — уменьшаем
  }
  throw new Error('canvas');
}
async function download(it, v, fmt, btn) {
  if (P.originalOnly) fmt = 'orig'; // на этой странице — только оригиналы
  const label = btn.textContent; btn.disabled = true; btn.textContent = 'Загрузка…';
  try {
    let blob;
    try { const r = await fetch(v.url, { mode: 'cors' }); if (!r.ok) throw new Error('HTTP ' + r.status); blob = await r.blob(); }
    catch (err) {
      if (fmt === 'orig') { window.open(v.url, '_blank', 'noopener'); return toast('Не удалось скачать напрямую — файл открыт в новой вкладке.', true); }
      return toast('Не удалось получить файл для конвертации (сеть или файл недоступен). Попробуйте «Оригинал».', true);
    }
    const ext = (decodeURIComponent(new URL(v.url, location.href).pathname).match(/\.([a-z0-9]+)$/i) || [, 'png'])[1].toLowerCase();
    const mime = blob.type.startsWith('image/') ? blob.type : (EXT_MIME[ext] || 'image/png');
    const origKey = mime === 'image/png' ? 'png' : mime === 'image/jpeg' ? 'jpeg' : '';
    const name = baseName(it, v);
    if (fmt === 'orig' || fmt === origKey) return save(blob, `${name}.${ext}`); // тот же формат — отдаём байты без потерь
    try {
      const { blob: out, resized } = await convert(blob, MIME[fmt]);
      save(out, `${name}.${fmt === 'jpeg' ? 'jpg' : 'png'}`);
      if (mime === 'image/gif') toast('Анимация GIF сохраняется только в оригинале — в PNG/JPEG попал первый кадр.');
      else if (resized) toast('Браузер не смог обработать полный размер — файл сохранён в уменьшенном разрешении.', true);
    } catch (err) { toast('Не удалось преобразовать изображение в этом браузере. Скачайте оригинал.', true); }
  } finally { btn.disabled = false; btn.textContent = label; }
}

/* ---------- удобства: избранное, навигация, ссылка, адрес страницы, тема ---------- */
function updFav() {
  el.fav.textContent = (state.favOnly ? '★' : '☆') + ' Избранное' + (favs.size ? ` (${favs.size})` : '');
  el.fav.setAttribute('aria-pressed', state.favOnly);
}
function toggleFav(it, btn) {
  const k = keyOf(it); favs.has(k) ? favs.delete(k) : favs.add(k);
  try { localStorage.setItem(favKey, JSON.stringify([...favs])); } catch (_) { /* не сохранится после закрытия */ }
  if (state.favOnly) return render();
  const on = favs.has(k); btn.classList.toggle('on', on); btn.textContent = on ? '★' : '☆'; updFav();
}
function step(d) {
  const L = state.list; if (L.length < 2) return;
  const k = L.findIndex(x => x.id === state.modalId);
  openModal(L[(k + d + L.length) % L.length].id);
}
function syncLink() { const it = byId.get(state.modalId); $('#mOpen').href = it.variants[state.vi.get(it.id) || 0].url; }
$('#mPrev').addEventListener('click', () => step(-1));
$('#mNext').addEventListener('click', () => step(1));
$('#mCopy').addEventListener('click', async () => {
  const it = byId.get(state.modalId), u = it.variants[state.vi.get(it.id) || 0].url;
  try { await navigator.clipboard.writeText(u); }
  catch (_) { const t = document.createElement('textarea'); t.value = u; document.body.append(t); t.select(); try { document.execCommand('copy'); } catch (__) { /* нечего делать */ } t.remove(); }
  toast('Ссылка на файл скопирована.');
});
el.fav.addEventListener('click', () => { state.favOnly = !state.favOnly; render(); });

const HASH = [['q', el.q], ['sec', el.sec], ['grp', el.grp], ['loc', el.loc], ['sea', el.sea], ['sort', el.sort]];
function writeHash() { // состояние поиска и фильтров в адресе — им можно поделиться
  const h = new URLSearchParams();
  HASH.forEach(([k, n]) => { if (n.value && !(k === 'sort' && n.value === P.sort)) h.set(k, n.value); });
  if (state.favOnly) h.set('fav', '1');
  const s = h.toString();
  try { history.replaceState(null, '', s ? '#' + s : location.pathname + location.search); } catch (_) { /* file:// в некоторых браузерах */ }
}
function readHash() {
  const h = new URLSearchParams(location.hash.slice(1));
  HASH.forEach(([k, n]) => { const v = h.get(k); if (v && (n === el.q || [...n.options].some(o => o.value === v))) n.value = v; });
  state.favOnly = h.get('fav') === '1';
}

const root = document.documentElement, themeBtn = $('#theme');
const curTheme = () => root.dataset.theme || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
const paintTheme = () => { themeBtn.textContent = curTheme() === 'dark' ? '☀️ Светлая тема' : '🌙 Тёмная тема'; };
themeBtn.addEventListener('click', () => {
  const n = curTheme() === 'dark' ? 'light' : 'dark'; root.dataset.theme = n;
  try { localStorage.setItem('theme', n); } catch (_) { /* тема не запомнится */ }
  paintTheme();
});
const toTop = $('#toTop');
addEventListener('scroll', () => { toTop.hidden = scrollY < 600; }, { passive: true });
toTop.addEventListener('click', () => scrollTo({ top: 0, behavior: 'smooth' }));

/* ---------- данные из репозитория: catalog.json (главный источник) или папка с файлами (запасной вариант) ---------- */
const DOP_CACHE = 'dop2:';
async function remoteCatalog(S) {
  try {
    const r = await fetch(DopLib.catalogUrl(S) + '?t=' + Math.floor(Date.now() / 6e4)); // ?t — чтобы не держался кэш CDN дольше минуты
    if (!r.ok) return null;
    const j = await r.json(); return Array.isArray(j.items) && j.items.length ? j : null;
  } catch (_) { return null; }
}
function applyCatalog(cat) {
  items.splice(0, items.length, ...cat.items.map((x, n) => ({ group: '', location: '', authors: '', section: '', ...x, id: n + 1 })));
  items.forEach(i => { i._s = norm([i.name, i.location, i.group, i.authors, i.section].join(' ')); });
  byId.clear(); items.forEach(i => byId.set(i.id, i)); state.vi.clear();
  buildFilters(); render();
}
async function dopFiles(S) {
  const api = `https://api.github.com/repos/${S.owner}/${S.repo}/contents/${S.path}?ref=${S.branch}`, ck = DOP_CACHE + api;
  let cached = null; try { cached = JSON.parse(localStorage.getItem(ck) || 'null'); } catch (_) { /* нет хранилища */ }
  if (cached && Date.now() - cached.t < 18e4) return cached.f;
  try {
    const r = await fetch(api, { headers: { Accept: 'application/vnd.github+json' } });
    if (r.status === 404) return [];
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const f = (await r.json()).filter(x => x.type === 'file' && /\.(png|jpe?g|gif|webp|avif|bmp)$/i.test(x.name)).map(x => ({ name: x.name, url: x.download_url, sha: x.sha }));
    try { localStorage.setItem(ck, JSON.stringify({ t: Date.now(), f })); } catch (_) { /* не критично */ }
    return f;
  } catch (err) {
    toast(cached ? 'Не удалось проверить новые файлы в папке — показаны сохранённые ранее.' : 'Не удалось проверить новые файлы в папке (возможно, лимит запросов GitHub). Основной каталог работает.', true);
    return cached ? cached.f : null;
  }
}
async function loadDop() {
  if (document.body.dataset.page !== 'index') return;
  const info = document.createElement('div'); info.className = 'dop-info'; $('.foot').append(info);
  if (!window.DopLib) { info.textContent = 'Не загружен файл lib.js — загрузите в репозиторий сайта ВСЕ файлы из архива.'; return; }
  const S = DopLib.source();
  const done = txt => {
    info.innerHTML = esc(`${txt} Версия сайта: ${DopLib.VERSION}.`) + ' <a href="#" id="dopRefresh">Проверить заново</a>';
    $('#dopRefresh').addEventListener('click', e => { e.preventDefault(); try { Object.keys(localStorage).filter(k => k.startsWith(DOP_CACHE)).forEach(k => localStorage.removeItem(k)); } catch (_) { /* ничего */ } location.reload(); });
  };
  const cat = await remoteCatalog(S);
  if (cat) { applyCatalog(cat); return done(`Данные взяты из catalog.json (${cat.items.length} фонов).`); }
  const files = await dopFiles(S);
  done((files === null ? 'Папка с новыми фонами не прочитана.' : `catalog.json не найден; из папки подхвачено файлов: ${files.length}.`) + (files && !files.length ? ' (папка пуста, не найдена или репозиторий приватный)' : ''));
  if (!files || !files.length) return;
  const touched = DopLib.merge(items, files);
  items.forEach(i => { if (!byId.has(i.id)) byId.set(i.id, i); });
  touched.forEach((label, it) => { it._s = norm([it.name, it.location, it.group, it.authors, it.section].join(' ')); state.vi.set(it.id, it.variants.findIndex(v => v.label === label)); });
  if (touched.size) { buildFilters(); render(); }
}

/* ---------- запуск ---------- */
let timer;
el.q.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(render, 120); });
[el.sec, el.grp, el.loc, el.sea, el.sort].forEach(s => s.addEventListener('change', render));
$('#reset').addEventListener('click', () => { el.q.value = ''; [el.sec, el.grp, el.loc, el.sea].forEach(s => { s.value = ''; }); el.sort.value = P.sort; state.favOnly = false; state.vi.clear(); render(); });

const miss = $('#missing');
if (missing.length) miss.innerHTML = `<summary>В таблице есть, но файла-изображения нет (${missing.length})</summary><ul>${missing.map(m => `<li>${esc(m.name)}${m.location ? ' — ' + esc(m.location) : ''} (${esc(m.reason)})${m.link ? ` <a href="${esc(m.link)}" target="_blank" rel="noopener">открыть ссылку</a>` : ''}</li>`).join('')}</ul>`;
else miss.hidden = true;
$('#built').textContent = `Данные таблицы от ${built}.`;
addEventListener('hashchange', () => { readHash(); render(); }); // вставили ссылку с фильтрами в ту же вкладку
readHash(); paintTheme(); render(); loadDop();
})();
